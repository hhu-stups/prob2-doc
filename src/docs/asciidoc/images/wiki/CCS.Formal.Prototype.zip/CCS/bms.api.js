var bms = bms || {};
var angular = angular || {};

(function() {
  bms = window.parent.bmsapi(window.frameElement.id);
  angular = window.parent.angular;
})();
