#!/bin/bash
PROBCOMMAND=prob

# Shell wrapper for PROBCOMMAND

echo "Running ProB"
#echo "$PROBCOMMAND" $*

# dirname
dirname=`dirname "$0"`

ulimit -d unlimited

echo "Directory: $dirname"
#cd $dirname
#ls
echo "$dirname/$PROBCOMMAND" $*
"$dirname/$PROBCOMMAND" $*