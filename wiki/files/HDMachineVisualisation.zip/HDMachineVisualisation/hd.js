requirejs(['bmotion.template'], function(bms) {
});
